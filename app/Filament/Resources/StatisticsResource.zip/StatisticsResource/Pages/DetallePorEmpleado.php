<?php
namespace App\Filament\Resources\StatisticsResource\Pages;

use App\Filament\Resources\StatisticsResource;
use App\Models\AttendanceRecord;
use App\Models\Employee;
use Filament\Actions;
use Filament\Forms;
use Filament\Pages\Page;
use Filament\Tables;
use Filament\Tables\Concerns\InteractsWithTable;
use Filament\Tables\Contracts\HasTable;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class DetallePorEmpleado extends Page implements HasTable
{
    use InteractsWithTable;

    protected static string $resource = StatisticsResource::class;
    protected static string $view = 'filament.resources.statistics.pages.detalle-por-empleado';

    public ?int $selectedEmployeeId = null;
    public string $desde;
    public string $hasta;

    public function mount(): void
    {
        $this->desde = now()->startOfMonth()->toDateString();
        $this->hasta = now()->endOfMonth()->toDateString();
    }

    protected function getHeaderActions(): array
    {
        return [
            Actions\Action::make('volver')
                ->label('← Ranking')
                ->url(StatisticsResource::getUrl('index'))
                ->color('gray'),
        ];
    }

    // Tabla 1: lista de empleados con resumen
    public function getTableQuery(): Builder
    {
        $user = Auth::user();

        return AttendanceRecord::query()
            ->select([
                'employee_id',
                DB::raw('SUM(CASE WHEN minutos_tardanza > 0 THEN 1 ELSE 0 END) as dias_tarde'),
                DB::raw('SUM(CASE WHEN minutos_tardanza <= 0 AND estado NOT IN ("ausente","feriado") THEN 1 ELSE 0 END) as dias_puntual'),
                DB::raw('SUM(CASE WHEN estado = "ausente" THEN 1 ELSE 0 END) as dias_ausente'),
                DB::raw('COUNT(*) as total_dias'),
                DB::raw('SUM(minutos_tardanza) as total_minutos'),
            ])
            ->with(['employee'])
            ->whereDate('fecha', '>=', $this->desde)
            ->whereDate('fecha', '<=', $this->hasta)
            ->when($user->company_id, function ($q) use ($user) {
                $q->whereHas('employee', fn($e) => $e->where('company_id', $user->company_id));
            })
            ->groupBy('employee_id');
    }

    protected function getTableColumns(): array
    {
        return [
            Tables\Columns\TextColumn::make('employee.nombre_completo')
                ->label('Empleado')
                ->searchable(),

            Tables\Columns\TextColumn::make('employee.department.nombre')
                ->label('Área'),

            // Barra visual días tarde vs puntual
            Tables\Columns\TextColumn::make('dias_tarde')
                ->label('Días tarde')
                ->badge()
                ->color('warning'),

            Tables\Columns\TextColumn::make('dias_puntual')
                ->label('Días puntual')
                ->badge()
                ->color('success'),

            Tables\Columns\TextColumn::make('dias_ausente')
                ->label('Ausencias')
                ->badge()
                ->color('danger'),

            Tables\Columns\TextColumn::make('total_dias')
                ->label('Total días'),

            Tables\Columns\TextColumn::make('total_minutos')
                ->label('Min. acumulados tarde')
                ->formatStateUsing(fn($state) => $state > 0 ? $state . ' min' : '—'),

            // Porcentaje puntualidad
            Tables\Columns\TextColumn::make('pct_puntualidad')
                ->label('% Puntualidad')
                ->getStateUsing(function ($record) {
                    if (!$record->total_dias) return '—';
                    $pct = round(($record->dias_puntual / $record->total_dias) * 100);
                    return $pct . '%';
                })
                ->badge()
                ->color(fn($state) => match(true) {
                    $state === '—'                   => 'gray',
                    (int)$state >= 90                => 'success',
                    (int)$state >= 70                => 'warning',
                    default                          => 'danger',
                }),

            Tables\Columns\TextColumn::make('detalle')
                ->label('')
                ->getStateUsing(fn() => 'Ver detalle')
                ->url(fn($record) => '#employee-' . $record->employee_id),
        ];
    }

    protected function getTableFilters(): array
    {
        return [
            Tables\Filters\Filter::make('periodo')
                ->form([
                    Forms\Components\DatePicker::make('desde')->default(now()->startOfMonth()),
                    Forms\Components\DatePicker::make('hasta')->default(now()->endOfMonth()),
                ])
                ->query(function ($query, array $data) {
                    $this->desde = $data['desde'] ?? $this->desde;
                    $this->hasta = $data['hasta'] ?? $this->hasta;
                    return $query
                        ->when($data['desde'], fn($q) => $q->whereDate('fecha', '>=', $data['desde']))
                        ->when($data['hasta'], fn($q) => $q->whereDate('fecha', '<=', $data['hasta']));
                }),
        ];
    }
}