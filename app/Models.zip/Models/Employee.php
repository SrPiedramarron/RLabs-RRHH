<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Employee extends Model
{
    use HasFactory;

    protected $fillable = [
        'company_id',
        'location_id',
        'department_id',
        'schedule_id',
        'nombres',
        'apellidos',
        'dni',
        'codigo_empleado',
        'cargo',
        'fecha_ingreso',
        'fecha_cese',
        'exonerado_registro',
        'motivo_exoneracion',
        'reloj_uid',
        'reloj_id',
        'active',
    ];

    protected $casts = [
        'fecha_ingreso'      => 'date',
        'fecha_cese'         => 'date',
        'exonerado_registro' => 'boolean',
        'active'             => 'boolean',
    ];

    // Relaciones
    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    public function location()
    {
        return $this->belongsTo(Location::class);
    }

    public function department()
    {
        return $this->belongsTo(Department::class);
    }

    public function schedule()
    {
        return $this->belongsTo(Schedule::class);
    }

    public function attendanceRecords()
    {
        return $this->hasMany(AttendanceRecord::class);
    }

    // Helpers
    public function getNombreCompletoAttribute(): string
    {
        return $this->apellidos . ', ' . $this->nombres;
    }

    public function getNombreCompletoNormalAttribute(): string
    {
        return $this->nombres . ' ' . $this->apellidos;
    }
}